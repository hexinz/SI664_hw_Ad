from django.apps import AppConfig


class StarsConfig(AppConfig):
    name = 'stars'
